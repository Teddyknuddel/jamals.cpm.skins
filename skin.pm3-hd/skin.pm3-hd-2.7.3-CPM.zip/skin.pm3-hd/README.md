The main goal of this branch is to keep this skin compatible with the latest stable version of Kodi.
